import react from "react";
import { render } from "@testing-library/react";
function Counter(){
    render()
    return(
        <div>
            <h3>Hello your data successfully readed.....</h3>
        </div>
    )
}
export default Counter