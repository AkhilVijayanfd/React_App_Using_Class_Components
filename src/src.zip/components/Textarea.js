import react from "react";
import { render } from "@testing-library/react"

function Textarea()
{
    
    render()
    return(
        <div className="textarea">
            <h2>Registration Form</h2>
            <br></br>
        </div>
    );
}
export default Textarea